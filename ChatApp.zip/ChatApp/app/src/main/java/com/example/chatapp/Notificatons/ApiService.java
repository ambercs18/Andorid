package com.example.chatapp.Notificatons;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiService {

    @Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAA7tm17Zs:APA91bF8ua1MppuZ0vgTRc2p7HZq8peSStJptTIgUMQtY_Rf8HhiW_ZWzK4TWtXLb-M7AuUMs1_TDffnvMC1jSIq1mjqPqaBDwbXoFPdI3SbWufd7thCQnrpHw7ouUc3_WnEyQVpARm3"

            }
    )

    @POST("fcm/send")
    Call<MyRespone> sendNotification(@Body Sender body);
}
