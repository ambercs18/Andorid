package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {
    MaterialEditText username,email,password;
    Button bt;
    FirebaseAuth auth;
    DatabaseReference ref;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Register");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        username=findViewById(R.id.username);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        bt=findViewById(R.id.register);

        auth= FirebaseAuth.getInstance();
       bt.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               String us=username.getText().toString();
               String pass=password.getText().toString();
               String e=email.getText().toString();

               if(TextUtils.isEmpty(us)||TextUtils.isEmpty(pass)||TextUtils.isEmpty(e))
               {
                   Toast.makeText(RegisterActivity.this, "All Fields are Required", Toast.LENGTH_SHORT).show();
               }
               else if(pass.length()<6)
                   Toast.makeText(RegisterActivity.this, "Password should at least be of length 6", Toast.LENGTH_SHORT).show();
               else
                   register(us,e,pass);
           }
       });
    }
    private void register(final String username, String email, String password)
    {
           auth.createUserWithEmailAndPassword(email,password)
                   .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                       @Override
                       public void onComplete(@NonNull Task<AuthResult> task) {
                           if(task.isSuccessful())
                           {
                               FirebaseUser firebaseuser=auth.getCurrentUser();
                               String userid=firebaseuser.getUid();

                               ref= FirebaseDatabase.getInstance().getReference("Users").child(userid);

                               HashMap<String,String> map =new HashMap<>();
                               map.put("id",userid);
                               map.put("username",username);
                               map.put("imageURL","default");
                               map.put("status","Offline");
                               map.put("search",username.toLowerCase());

                               ref.setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                                   @Override
                                   public void onComplete(@NonNull Task<Void> task) {
                                       if(task.isSuccessful())
                                       {
                                           Intent intent=new Intent(RegisterActivity.this,HomeActivity.class);
                                           intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                           startActivity(intent);
                                           finish();
                                       }

                                   }
                               });

                           }
                           else
                           {
                               Toast.makeText(RegisterActivity.this, "Invalid id and password", Toast.LENGTH_SHORT).show();
                           }

                       }
                   });

    }
}
