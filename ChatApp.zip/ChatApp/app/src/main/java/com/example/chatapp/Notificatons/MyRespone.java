package com.example.chatapp.Notificatons;

public class MyRespone {

    public  int success;
}
