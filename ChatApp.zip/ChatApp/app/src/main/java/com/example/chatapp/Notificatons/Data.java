package com.example.chatapp.Notificatons;

public class Data {

    private String user;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }

    private int icon;

    public Data(String user, int icon, String title, String body, String s) {
        this.user = user;
        this.icon = icon;
        this.title = title;
        this.body = body;
        this.s = s;
    }

    public Data()
    {

    }

    private String title;
    private String body;
    private String s;

}
