package com.example.chatapp.Notificatons;

public class Sender {

    public Sender(Data data, String to) {
        this.data = data;
        this.to = to;
    }

    public  Data data;
    public String to;
}
