package application;

public class Tab2 {
	String name,id,price,qt;

	public Tab2(String name, String id, String price,String qt) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
		this.qt=qt;
	}

	public String getName() {
		return name;
	}
	public String getQt() {
		return qt;
	}
	public void setQt(String qt) {
		this.qt = qt;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	

}
