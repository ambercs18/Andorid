package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

public class Bill implements Initializable {
	@FXML
	TextField tf;
	@FXML
	TableView<Tab2> table;
	@FXML
	TableColumn<Tab2,String> name;
	@FXML
	TableColumn<Tab2,String> id;
	@FXML
	TableColumn<Tab2,String> price;
	@FXML
	TableColumn<Tab2,String> qt;
	@FXML
	Label item;
	@FXML
	TextField q;
	@FXML
	AnchorPane root;
	@FXML
	TextField no;
	@FXML
	Label disc,amt,gmt,dmt,fmt;
	@FXML
	Button billing,newC,custDet,about;
	@FXML
	Button stock;
	@FXML
	ComboBox<String> cb;
	int quant;
	ObservableList<Tab2> ar=FXCollections.observableArrayList();
	ObservableList<String> br=FXCollections.observableArrayList("Cash","Debit Card","UPI Pin","Net Banking");
	int tot=0;
	int cp=0;
	int sq=0;
	int rid=0;
	public void fun(ActionEvent ev) throws ClassNotFoundException, SQLException
	{	
		rid=Integer.parseInt(tf.getText());
		name.setCellValueFactory(new PropertyValueFactory<>("name"));
		id.setCellValueFactory(new PropertyValueFactory<>("id"));
		price.setCellValueFactory(new PropertyValueFactory<>("price"));
		qt.setCellValueFactory(new PropertyValueFactory<>("qt"));
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select * from Item where item_id="+rid);
	    while(rt.next())
	    {
	    	item.setText(rt.getString(2));
	    	ar.add(new Tab2(rt.getString(2),Integer.toString(rt.getInt(1)),Integer.toString((int)rt.getFloat(3)),Integer.toString(quant)));
	    	cp=(int)rt.getInt(3);
	    }
	    
	    table.setItems(ar);
	    tot+=quant*cp;
	 //   tot+=Integer.parseInt(q.getText())*cp;
	}
	public void discount(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		String ph=no.getText();
		//int d=0;
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select ctype,expdate from Card where cust_id in(select cust_id from Customer where cphone="+ph+")");
	    while(rt.next())
	    {
	    	String type=rt.getString(1);
	    	Date n=rt.getDate(2);
	    	java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
	    	if(date.before(n))
	    	{
	    	if(type.equals("Gold"))
				disc.setText("30%");
			else if(type.equals("Silver"))
				disc.setText("20%");
			else if(type.equals("Bronze"))
				disc.setText("10%");
			else
				disc.setText("00");
	    	}
	    	else
	    	{
	    		Alert a1=new Alert(Alert.AlertType.WARNING);
				a1.setTitle("Warning");
				a1.setContentText("Card Expired!!");
				a1.setHeaderText(null);
				a1.show();
				disc.setText("00");
	    	}
	    }
	}
	public void gen(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		//root.setLayoutY(-100);
		String ph=no.getText();
		int cid = 0;
		int card = 0;
		float d=0;
		amt.setText("Total amount : "+Integer.toString(tot));
		int gst=tot+(int)(0.1*tot);
		gmt.setText("Amount after adding GST : "+Integer.toString(gst));
		if(disc.getText().substring(0,2).equals("Nu"))
			d=0;
		else
		 d=(Float.parseFloat((disc.getText().substring(0,2))))/100;
		int disc=(int) (d*gst);
		d=gst-(int)(d*gst);
		dmt.setText("Amount after applying Discount : "+Float.toString(d));
		int tmt=(int)d;
		fmt.setText(Float.toString(d));
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select cust_id from customer where cphone ="+ph);
	    while(rt.next())
	    	cid=rt.getInt(1);
	    rt=s.executeQuery("select card_id from Card where cust_id="+cid);
	    while(rt.next())
	    	card=rt.getInt(1);
	   // java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
	    java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		String dt=date.toString();
		
	    String st="insert into Receipt(cust_id,t_date,total_items,disc_amt,total_amt,card_id) values(?,?,?,?,?,?)"; 
	    PreparedStatement sr= con.prepareStatement(st); 
	    sr.setInt(1,cid);
	    sr.setString(2,dt);
	    sr.setInt(3,sq);
	    sr.setInt(4,disc);
	    sr.setInt(5,tmt);
	    sr.setInt(6,card);
	    sr.executeUpdate();
	}
	public void get(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		int n=0;
		quant=Integer.parseInt(q.getText());
		rid=Integer.parseInt(tf.getText());
		sq+=quant;
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select q from Item where item_id ="+rid);
	    while(rt.next())
	    	n=rt.getInt(1);
	    n=n-quant;
	    if(n<0)
	    {
	    	Alert a1=new Alert(Alert.AlertType.WARNING);
			a1.setTitle("Warning");
			a1.setContentText("Item Not Present!!");
			a1.setHeaderText(null);
			a1.show();
	    	n=0;
	    }
	    String st="update Item set q = ? where item_id="+rid;
	    PreparedStatement sr= con.prepareStatement(st); 
	    sr.setInt(1,n);
	    sr.executeUpdate();
	}
	public void search(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayout.fxml"));
		root.getChildren().setAll(ap);
	}
	public void signup(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
		root.getChildren().setAll(ap);
	}
	public void stock(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/Stock.fxml"));
		root.getChildren().setAll(ap);
	}
	public void about(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/AboutUs.fxml"));
		root.getChildren().setAll(ap);
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cb.setItems(br);
		// TODO Auto-generated method stub
		
	}

}
