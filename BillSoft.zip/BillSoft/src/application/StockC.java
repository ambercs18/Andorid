package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

public class StockC implements Initializable
{
	@FXML
	TableView<Tab4> t;
    @FXML
    TableColumn<Tab4,String> id,name,c,q;
    @FXML
    Label lb;
    @FXML
	AnchorPane root;
    ObservableList<Tab4> ar=FXCollections.observableArrayList();
    ArrayList<Integer> l=new ArrayList<>();
   // ObservableValue<String> ar2=FXCollections.observableArrayList();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//if(t.contains(1,2))
		lb.setVisible(false);
		id.setCellValueFactory(new PropertyValueFactory<>("id"));
		name.setCellValueFactory(new PropertyValueFactory<>("name"));
		c.setCellValueFactory(new PropertyValueFactory<>("c"));
		q.setCellValueFactory(new PropertyValueFactory<>("q"));
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
		    Statement s=con.createStatement();
		    ResultSet rt=s.executeQuery("select * from Item where q<10");
		    while(rt.next())
		    {
		    	ar.add(new Tab4(Integer.toString(rt.getInt(1)),rt.getString(2),Float.toString(rt.getFloat(3)),Integer.toString(rt.getInt(4))));
		    	
		    }
		    t.setItems(ar);
		    if(ar.size()==0)
		    {
		    	t.setVisible(false);
		    	lb.setVisible(true);
		    }
		   
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		
	}
	public void fill(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select item_id from Item where q<10");
	    while(rt.next())
	    	l.add(rt.getInt(1));
	    while(ar.size()!=0)
	    {
	    	int a=l.get(0);
	    	  String st="update Item set q = ? where item_id="+a;
	  	    PreparedStatement sr= con.prepareStatement(st); 
	  	    sr.setInt(1,20);
	  	    sr.executeUpdate();
	  	    ar.remove(0);
	    }
	    t.setVisible(false);
	    lb.setVisible(true);
	}
	public void bill(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayoutBilling.fxml"));
		root.getChildren().setAll(ap);
	}
	public void newC(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
		root.getChildren().setAll(ap);
	}
	public void cust(ActionEvent ev) throws IOException
	{
		
			AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
			root.getChildren().setAll(ap);
		
	}
	public void about(ActionEvent ev) throws IOException
	{
		
			AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/AboutUs.fxml"));
			root.getChildren().setAll(ap);
		
	}

}
