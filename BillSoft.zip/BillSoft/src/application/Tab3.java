package application;

public class Tab3 {
	String cid,ctype,cname,cno,exp,dis;

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getCtype() {
		return ctype;
	}

	public void setCtype(String ctype) {
		this.ctype = ctype;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

	public String getDis() {
		return dis;
	}

	public void setDis(String dis) {
		this.dis = dis;
	}

	public Tab3(String cid, String ctype, String cname, String cno, String exp, String dis) {
		super();
		this.cid = cid;
		this.ctype = ctype;
		this.cname = cname;
		this.cno = cno;
		this.exp = exp;
		this.dis = dis;
	}


}
