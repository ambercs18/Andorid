package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Control {
	@FXML
	Label msg;
	@FXML
	TextField user;
	@FXML
	TextField pass;
	@FXML
	AnchorPane root;
	public void check(ActionEvent ev) throws IOException, ClassNotFoundException, SQLException
	{
		if(user.getText().isEmpty()||pass.getText().isEmpty())
		{
			Alert a1=new Alert(Alert.AlertType.WARNING);
			a1.setTitle("Warning");
			a1.setContentText("Empty Fields");
			a1.setHeaderText(null);
			a1.show();
		}
		else if(check(user.getText(), pass.getText()))
		{
			/*Parent root=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
			Scene scene = new Scene(root,400,400);
			Stage primaryStage=new Stage();
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();*/
			AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
			root.getChildren().setAll(ap);
		}
		else
		{
			Alert a1=new Alert(Alert.AlertType.ERROR);
			a1.setTitle("Error");
			a1.setContentText("Invalid Fields");
			a1.setHeaderText(null);
			a1.show();
		}
	}
	public void signup(ActionEvent ev) throws IOException
	{
		/*Parent root=FXMLLoader.load(getClass().getResource("/application/Signup.fxml"));
		Scene scene = new Scene(root,400,400);
		Stage primaryStage=new Stage();
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();*/
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/Signup.fxml"));
		root.getChildren().setAll(ap);
		
	}
	public static boolean check(String n,String p) throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ab","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select * from supplier");
	    while(rt.next())
	    {
	  String  pass=rt.getString(4);
	    String nm=rt.getString(3);
	    if(p.equals(pass)&&n.equals(nm))
	    	return true;
	    }
	    return false;
	}

}
