package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CustLogin {
	@FXML
	TextField num;
	@FXML
    Label msg;
	@FXML
	AnchorPane root;
	public void check(ActionEvent ev) throws IOException, ClassNotFoundException, SQLException
	{
		if(num.getText().isEmpty())
		{
			Alert a1=new Alert(Alert.AlertType.WARNING);
			a1.setTitle("Warning");
			a1.setContentText("Empty Fields");
			a1.setHeaderText(null);
			a1.show();
		}
		else if(check(num.getText()))
		{
			/*Parent root=FXMLLoader.load(getClass().getResource("/application/Main.fxml"));
			Scene scene = new Scene(root,400,400);
			Stage primaryStage=new Stage();
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();*/
			AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayout.fxml"));
			Scene s=new Scene(ap,400,400);
			s.getStylesheets().add(getClass().getResource("mainLayout.css").toExternalForm());
			root.getChildren().setAll(ap);
		}
		else
		{
			Alert a1=new Alert(Alert.AlertType.ERROR);
			a1.setTitle("Error");
			a1.setContentText("Invalid Fields");
			a1.setHeaderText(null);
			a1.show();
		}
	}
	public boolean check(String st) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select * from Customer");
	    while(rt.next())
	    {
	    	String a=rt.getString(5);
	    	if(a.equals(st))
	    		return true;
	    }
	    return false;
	}
	/*public void show(ActionEvent ev)
	{
		Alert a1=new Alert(Alert.AlertType.WARNING);
		a1.setTitle("Empty Fields");
		a1.setContentText("Empty Fields");
		a1.setHeaderText(null);
		a1.show();
		
	}*/

}
