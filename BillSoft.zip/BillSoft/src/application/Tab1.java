package application;

public class Tab1 {
	String rep,date,it,amt,disc;

	public String getRep() {
		return rep;
	}

	public void setRep(String rep) {
		this.rep = rep;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getIt() {
		return it;
	}

	public void setIt(String it) {
		this.it = it;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getDisc() {
		return disc;
	}

	public void setDisc(String disc) {
		this.disc = disc;
	}

	public Tab1(String rep, String date, String it, String amt, String disc) {
		super();
		this.rep = rep;
		this.date = date;
		this.it = it;
		this.amt = amt;
		this.disc = disc;
	}

	

}
