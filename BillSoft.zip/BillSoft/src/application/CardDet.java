package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

public class CardDet {
	@FXML
	TextField mob;
	@FXML
	TableView<Tab3> table;
	@FXML
	TableColumn<Tab3,String> cid,ctype,cname,cno,exp,dis;
	@FXML
	AnchorPane root;
	
	ObservableList<Tab3> ar=FXCollections.observableArrayList();
	public void show(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		String ph=mob.getText();
		if(ph.isEmpty())
		{
			Alert a1=new Alert(Alert.AlertType.WARNING);
			a1.setTitle("Warning");
			a1.setContentText("Empty Fields");
			a1.setHeaderText(null);
			a1.show();
		}
		else
		{
			cid.setCellValueFactory(new PropertyValueFactory<>("cid"));
			ctype.setCellValueFactory(new PropertyValueFactory<>("ctype"));
			cname.setCellValueFactory(new PropertyValueFactory<>("cname"));
			cno.setCellValueFactory(new PropertyValueFactory<>("cno"));
			exp.setCellValueFactory(new PropertyValueFactory<>("exp"));
			dis.setCellValueFactory(new PropertyValueFactory<>("dis"));
			//String no=ph.getText();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
		    Statement s=con.createStatement();
		    ResultSet rt=s.executeQuery("select distinct Card.card_id, Card.ctype, cname, cphone, expdate, disc_percent from Customer,Card,Discount where Card.cust_id = Customer.cust_id and Discount.ctype =Card.ctype and cphone=+"+ph);
		  //  ResultSet rt2=s.executeQuery("select card_id,ctype,expdate from Card where cust_id =(select cust_id from Customer where cphone ="+ph+")");
		    String w="";
		    while(rt.next())
		    {
		    	if(rt.getString(2).equals("Gold"))
		    		w="30%";
		    	else if(rt.getString(2).equals("Silver"))
		    		w="20%";
		    	else if(rt.getString(3).equals("Bronze"))
		    		w="10%";
		    	else
		    		w="Null";
		    		
		    	
		    	ar.add(new Tab3(Integer.toString(rt.getInt(1)),rt.getString(2),rt.getString(3),rt.getString(4),rt.getString(5),w));
		    }
		    if(ar.isEmpty())
		    {
		    	Alert a1=new Alert(Alert.AlertType.ERROR);
				a1.setTitle("Error");
				a1.setContentText("Customer has no Card");
				a1.setHeaderText(null);
				a1.show();
		    }
		    else
		    table.setItems(ar);
		    

		}
		
	}
	public void bill(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayoutBilling.fxml"));
		root.getChildren().setAll(ap);
	}
	public void newC(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
		root.getChildren().setAll(ap);
	}
	public void det(ActionEvent ev) throws IOException
	{

		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayout.fxml"));
		root.getChildren().setAll(ap);
	}

}
