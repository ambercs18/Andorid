package application;

public class Tab4 {
	String id,name,c,q;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getQ() {
		return q;
	}

	public void setQ(String q) {
		this.q = q;
	}

	public Tab4(String id, String name, String c, String q) {
		super();
		this.id = id;
		this.name = name;
		this.c = c;
		this.q = q;
	}


}
