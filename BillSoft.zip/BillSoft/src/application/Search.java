package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

public class Search implements Initializable {
	@FXML
	TableView<Tab1> table;
	@FXML
	TextField ph;
	@FXML
	TableColumn<Tab1,String> disc,it,amt,rep,date;
	@FXML
	AnchorPane root;
	@FXML
	Button billing,newC,custDet,about;
	@FXML
	Button stock;
	@FXML
	Label c,n,a,g,s,e;
	ObservableList<Tab1> ar=FXCollections.observableArrayList();
	public void fun(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		if(ph.getText().isEmpty())
		{
			Alert a1=new Alert(Alert.AlertType.WARNING);
			a1.setTitle("Warning");
			a1.setContentText("Empty Fields");
			a1.setHeaderText(null);
			a1.show();
		}
		else
		{
		/*id.setCellValueFactory(new PropertyValueFactory<>("id"));
		name.setCellValueFactory(new PropertyValueFactory<>("name"));
		
		age.setCellValueFactory(new PropertyValueFactory<>("age"));
		sex.setCellValueFactory(new PropertyValueFactory<>("sex"));
		rep.setCellValueFactory(new PropertyValueFactory<>("rep"));
		date.setCellValueFactory(new PropertyValueFactory<>("date"));*/
			rep.setCellValueFactory(new PropertyValueFactory<>("rep"));
			date.setCellValueFactory(new PropertyValueFactory<>("date"));
			it.setCellValueFactory(new PropertyValueFactory<>("it"));
			amt.setCellValueFactory(new PropertyValueFactory<>("amt"));
			disc.setCellValueFactory(new PropertyValueFactory<>("disc"));
		String no=ph.getText();
		int cid=0;
		a.setVisible(true);
		g.setVisible(true);
		c.setVisible(true);
		n.setVisible(true);
		s.setVisible(true);
		e.setVisible(true);
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select * from Customer where cphone="+no);
	    while(rt.next())
	    {
	    	cid=rt.getInt(1);
	    	n.setText(rt.getString(2));
	    	g.setText(rt.getString(4));
	    	e.setText(rt.getString(3));
	    	//ar.add(new Tab1(rt.getString(2),Integer.toString(rt.getInt(4)),rt.getString(3),"15-05-2020",Integer.toString(rt.getInt(1)),"2"));
	    }
	    rt=s.executeQuery("select * from Receipt where cust_id="+cid);
	    while(rt.next())
	    {
	    	ar.add(new Tab1(Integer.toString(rt.getInt(1)),rt.getDate(3).toString(),Integer.toString(rt.getInt(4)),Integer.toString(rt.getInt(5)),Integer.toString(rt.getInt(6))));
	    }
	    table.setItems(ar);
		}
	}
	public void signup(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
		root.getChildren().setAll(ap);
	}
	public void bill(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayoutBilling.fxml"));
		root.getChildren().setAll(ap);
	}
	public void card(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/Project1.fxml"));
		root.getChildren().setAll(ap);
	}
	public void stock(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/Stock.fxml"));
		root.getChildren().setAll(ap);
	}
	public void about(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/AboutUs.fxml"));
		root.getChildren().setAll(ap);
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		a.setVisible(false);
		g.setVisible(false);
		c.setVisible(false);
		n.setVisible(false);
		s.setVisible(false);
		e.setVisible(false);
		// TODO Auto-generated method stub
		
	}

	

}
