package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CustSign implements Initializable {
	@FXML
	TextField n;
	@FXML
	TextField pn;
	@FXML
	TextField age;
	@FXML
	ComboBox<String> cb;
	@FXML
	ComboBox<String> card;
	ObservableList<String> ar=FXCollections.observableArrayList("Male","Female");
	ObservableList<String> br=FXCollections.observableArrayList("Gold","Silver","Bronze","Null");
	String sex="";
	int id=0;
	int cid=1;
	@FXML
	AnchorPane root;
	String type="";
	int d=0;
	public void sex(ActionEvent ev)
	{
		sex=cb.getValue();
	}
	public void card(ActionEvent ev)
	{
		type=card.getValue();
		if(type.equals("Gold"))
			d=30;
		else if(type.equals("Silver"))
			d=20;
		else if(type.equals("Bronze"))
			d=10;			
	}
	public void sign(ActionEvent ev) throws ClassNotFoundException, SQLException, IOException
	{
		if(n.getText().isEmpty()||pn.getText().isEmpty()||age.getText().isEmpty())
		{
			Alert a1=new Alert(Alert.AlertType.WARNING);
			a1.setTitle("Warning");
			a1.setContentText("Empty Fields");
			a1.setHeaderText(null);
			a1.show();
		}
		else
		{
		String name=n.getText();
		String no=pn.getText();
		int a=Integer.parseInt(age.getText());
		//String sex=
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
		String s="insert into Customer(cust_id,cname,csex,cage,cphone) values (?,?,?,?,?)";
		PreparedStatement st= con.prepareStatement(s);
		st.setInt(1,id);
		st.setString(2,name);
		st.setString(3,sex);
		st.setInt(4,a);
		st.setString(5,no);
		st.executeUpdate();
		 s="insert into Discount(ctype,disc_percent,card_id) values (?,?,?)";
		st=con.prepareStatement(s);
		st.setString(1,type);
		st.setInt(2,d);
		st.setInt(3,cid);
		st.executeUpdate();
		//java.util.Date date=new java.util.Date();  
		//String d=date.toString();
	    java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		String dt=date.toString();
		int y=Integer.parseInt(dt.substring(0,4))+1;
		String w=Integer.toString(y)+dt.substring(4,dt.length());
		s="insert into Card(card_id,cust_id,ctype,expdate) values(?,?,?,?)";
		st=con.prepareStatement(s);
		st.setInt(1,cid);
		st.setInt(2,id);
		st.setString(3,type);
		st.setString(4,w);
		st.executeUpdate();
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayoutBilling.fxml"));
		root.getChildren().setAll(ap);
		}
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		cb.setItems(ar);
		card.setItems(br);
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
		 Statement s=con.createStatement();
		    ResultSet rt=s.executeQuery("select * from Customer");
		    while(rt.next())
		    {
		    	id=rt.getInt(1)+1;
		    }
		     rt=s.executeQuery("select * from Discount");
		     while(rt.next())
		    	 cid=rt.getInt(3)+1;
		    
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		System.out.print(id);
		
	}
	public void login(ActionEvent ev) throws IOException
	{

		/*Parent root=FXMLLoader.load(getClass().getResource("/application/custLogin.fxml"));
		Scene scene = new Scene(root,400,400);
		Stage primaryStage=new Stage();
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();*/
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/custLogin.fxml"));
		root.getChildren().setAll(ap);
	}

}
