package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;

public class AboutC {
	@FXML
	AnchorPane root;
	@FXML
	TextArea t;
	public void bill(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/mainLayoutBilling.fxml"));
		root.getChildren().setAll(ap);
	}
	public void newC(ActionEvent ev) throws IOException
	{
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
		root.getChildren().setAll(ap);
	}
	public void cust(ActionEvent ev) throws IOException
	{
		
			AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
			root.getChildren().setAll(ap);
		
	}
	public void stock(ActionEvent ev) throws IOException
	{

		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/Stock.fxml"));
		root.getChildren().setAll(ap);
	}
	public void fun(ActionEvent ev)
	{
		t.clear();
		Alert a1=new Alert(Alert.AlertType.INFORMATION);
		a1.setTitle("Thank You :)");
		a1.setContentText("Feedback Recieved");
		a1.setHeaderText(null);
		a1.show();
	}

}
