package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class Sign extends AppCompatActivity {
    EditText mail,username,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);
        mail=findViewById(R.id.mail);
        username=findViewById(R.id.username);
        pass=findViewById(R.id.pass);
    }
    public void sign(View v)
    {
        if(TextUtils.isEmpty(mail.getText())||TextUtils.isEmpty(pass.getText())||TextUtils.isEmpty(username.getText()))
            Toast.makeText(this, "All Fields are Required", Toast.LENGTH_SHORT).show();
        else
        {
            ParseUser user = new ParseUser();
            user.setUsername(username.getText().toString());
            user.setPassword(pass.getText().toString());
            user.setEmail(mail.getText().toString());

            user.signUpInBackground(new SignUpCallback() {
                public void done(ParseException e) {
                    if (e == null) {
                        Toast.makeText(Sign.this, "Welcome!!", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(Sign.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        ParseUser.logOut();
                        Toast.makeText(Sign.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }

}
