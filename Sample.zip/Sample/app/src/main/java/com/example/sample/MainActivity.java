package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseInstallation;
import com.parse.ParseUser;

public class MainActivity extends AppCompatActivity {
    EditText mail,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ParseInstallation.getCurrentInstallation().saveInBackground();

        mail=findViewById(R.id.mail);
        pass=findViewById(R.id.pass);

        if(ParseUser.getCurrentUser()!=null)
        {
            Intent intent=new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);
            finish();
        }

    }
    public void login(View v)
    {
         if(TextUtils.isEmpty(mail.getText())||TextUtils.isEmpty(pass.getText()))
             Toast.makeText(this, "Both Fields are Required", Toast.LENGTH_SHORT).show();
         else
         {
             ParseUser.logInInBackground(mail.getText().toString(),pass.getText().toString(), new LogInCallback() {
                 public void done(ParseUser user, ParseException e) {
                     if (user != null) {
                         Toast.makeText(MainActivity.this, "Welcome Back!!", Toast.LENGTH_SHORT).show();
                         Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                         startActivity(intent);
                         finish();
                         // Hooray! The user is logged in.
                     } else {
                         ParseUser.logOut();
                         Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                         // Signup failed. Look at the ParseException to see what happened.
                     }
                 }
             });
         }

    }
    public void sign(View v)
    {
        Intent intent=new Intent(MainActivity.this,Sign.class);
        startActivity(intent);
      //  finish();
    }
}
