package com.example.sample;

import android.app.Application;

import com.example.sample.MainActivity;
import com.parse.Parse;

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("XSRRNWalRJNPUOLpvWiVu2tK9dPaOExmKZoYyooK")
                .clientKey("6zfs4P7F5ehG6V3tCpFy0aPBBnSfc1sLNxMkoUXD")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }


}
